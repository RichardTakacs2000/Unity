﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playercontroller : MonoBehaviour
{

    public Transform player;
    private float speed = 0;
    private float rotate=5;
    // Update is called once per frame
    void FixedUpdate()
    {
        transform.Translate(Vector3.up*speed*Time.deltaTime*0.1f);
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
        {
            speed+=5;
        }
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
        {
            speed-=5;
        }
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            
            transform.Rotate(new Vector3(0, 0, -rotate));
        }
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
           
            transform.Rotate(new Vector3(0,0,rotate));
        }

    }
}
