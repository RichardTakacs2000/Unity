﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject enemy;
    float randX;
    float randY;
    Vector2 wheretToSpawn;
    public float spawnRate = 2f;
    float nextSpawn = 0.0f;
    int mennyiseg=0;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Time.time > nextSpawn && mennyiseg<10)
        {
            mennyiseg++;
            nextSpawn = Time.time + spawnRate;
            randX = Random.Range(-50, 50);
            randY = Random.Range(-100, 100);
            wheretToSpawn = new Vector2(randX, randY);
            Instantiate(enemy, wheretToSpawn, Quaternion.identity);

           

        }
        
    }
}
