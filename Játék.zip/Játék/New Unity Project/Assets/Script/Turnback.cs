﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turnback : MonoBehaviour
{
    // Start is called before the first frame update
    public float tavolsag;
    public Transform player;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Vector2.Distance(transform.position,player.position)>=tavolsag)
        {
            player.position = new Vector3(0,0,0);
            
        }
        
    }
}
